#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/time.h>
#include <errno.h>
#include <signal.h>

#define SIZE_ARRAY(x)	(sizeof(x)/sizeof(x[0]))
int buttons_fd;

void signal_handler (int signum) {

	int i;
	char buttons[1] = {'0'};

	if (signum == SIGIO)
	{
		printf("APP:---->Button pressed<-----\n");
		if (read(buttons_fd, buttons, sizeof buttons)==0) {
			perror("read buttons error");
		}
		for (i = 0; i < SIZE_ARRAY(buttons); i++) {
				
			 printf("K%d = %c \n", i, buttons[i]);
		}
	}
	return;                  
}

void init_signal(void)
{
	signal(SIGIO,signal_handler);
}


int main(void)
{
	

	buttons_fd = open("/dev/my_buttons", O_RDWR);
	if (buttons_fd < 0) {
		perror("open device buttons");
		exit(1);
	}
	printf("open device buttons xxx ok\n");
	
	printf("my pid:%d\n",getpid());
	
	init_signal();
	
	for (;;) {
		
	}

	close(buttons_fd);
	return 0;
}

