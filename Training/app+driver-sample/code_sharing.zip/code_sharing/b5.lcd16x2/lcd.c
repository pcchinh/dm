#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/* in the /dev/mygpio device file:
 * 	gpio number: 	0	-> GPIOA7, 
 *					1	-> GPIOA8,
 *					2	-> GPIOA9,
 *					3	-> GPIOA10
 *					4	-> GPIOA20,
 *					5	-> GPIOA21,
 *					6	-> GPIOD14
 *					7	-> GPIOC4
 *					8	-> GPIOC7
*/

#define LCD_D4_PIN	0	
#define LCD_D5_PIN	1
#define LCD_D6_PIN	2
#define LCD_D7_PIN	3
#define LCD_RS		4			//GPIOA20
#define LCD_EN		5			//GPIOA21
#define LCD_DATA	(unsigned char)0x0F	//GPIOA7..10

#define LCD_WRITE(fd,n)	{ioctl(fd, (n>>0)&1, LCD_D4_PIN);\
			 ioctl(fd, (n>>1)&1, LCD_D5_PIN);\
			 ioctl(fd, (n>>2)&1, LCD_D6_PIN);\
			 ioctl(fd, (n>>3)&1, LCD_D7_PIN);}

int gpio_fd;


inline void clear_cntrl_data_lcd (void) __attribute__((always_inline));

inline void clear_cntrl_data_lcd(void)
{
	LCD_WRITE(gpio_fd, 0x00);
	ioctl(gpio_fd, 0, LCD_EN);
	ioctl(gpio_fd, 0, LCD_RS);
}


void sleep_ms(int milliseconds)
{
	usleep(milliseconds * 1000);
}

void lcd_cmd (unsigned char cmd)
{
	unsigned char high_nibble, low_nibble;

	high_nibble = (cmd >>4)&LCD_DATA;	
	low_nibble  = (cmd)&LCD_DATA; 
		
	//Clear all lcd control pins
	clear_cntrl_data_lcd();
	
	LCD_WRITE(gpio_fd, high_nibble);
	ioctl(gpio_fd, 1, LCD_EN);	//E=1
	sleep_ms(1);
	ioctl(gpio_fd, 0, LCD_EN);	//E=0
	sleep_ms(5);

	//Clear all lcd control pins
	clear_cntrl_data_lcd();

	LCD_WRITE(gpio_fd, low_nibble);
	ioctl(gpio_fd, 1, LCD_EN);	//E=1
	sleep_ms(1);
	ioctl(gpio_fd, 0, LCD_EN);	//E=0
	sleep_ms(10);
}
void lcd_data (unsigned char dat)
{
	unsigned int high_nibble, low_nibble;
		
	high_nibble = (dat >>4)&LCD_DATA;
	low_nibble  = (dat)&LCD_DATA;
		
	//Clear all lcd control pins
	clear_cntrl_data_lcd();
	ioctl(gpio_fd, 1, LCD_RS);	//RS=1
	LCD_WRITE(gpio_fd, high_nibble);
	ioctl(gpio_fd, 1, LCD_EN);	//E=1
	sleep_ms(1);
	ioctl(gpio_fd, 0, LCD_EN);	//E=0
	sleep_ms(5);
		
	//Clear all lcd control pins
	clear_cntrl_data_lcd();
	ioctl(gpio_fd, 1, LCD_RS);	//RS=1
	LCD_WRITE(gpio_fd, low_nibble);
	ioctl(gpio_fd, 1, LCD_EN);	//E=1
	sleep_ms(1);
	ioctl(gpio_fd, 0, LCD_EN);	//E=0 
	sleep_ms(10);    
}

void lcd_init(void)
{						// waiting for the power of lcd stables
	sleep_ms(10);
				  		// Set for 4 bit LCD mode
	lcd_cmd(0x33);       
	sleep_ms(200);
	lcd_cmd(0x32);       
	sleep_ms(200);

	lcd_cmd(0x28);       // 4-bit mode - 2 line - 5x7 font.
	sleep_ms(200);
	
	lcd_cmd(0x0C);
	sleep_ms(200);
		        
	lcd_cmd(0x06);       // Automatic Increment - No Display shift.
	sleep_ms(200);
        		
	lcd_cmd(0x01);       // Automatic Increment - No Display shift.
	sleep_ms(200);
}

void lcd_clear(void)
{
	lcd_cmd(0x01);       // Clear.
	sleep_ms(100);
}

void StrDisplay(char *str, unsigned char index, unsigned char lines)
{

	if(lines == 1)
		lcd_cmd(0x80 + index);
	else if(lines == 2) 
		lcd_cmd(0xc0 + index);
	
	sleep_ms(10);
	while(*str != '\0')
	{
		lcd_data(*str++);	
	}
}

void CHARACTER_TO_LCD_HEX(unsigned char x)
{
	unsigned char tmp;
	tmp =x;

	if (tmp<0x0A)
	{
		tmp = tmp | 0x30;
		lcd_data(tmp);
	}
	else
	{
		tmp = tmp + 0x37;
		lcd_data(tmp);
	}
}

void CHARACTER_TO_BCD(unsigned char x, unsigned char index, unsigned char line)
{

	unsigned char tmp;
	if(line == 1)
		lcd_cmd(0x80 + index);
	else if(line == 2) 
		lcd_cmd(0xc0 + index);
	else if(line == 3)
		lcd_cmd(0x94 + index);
	else
		lcd_cmd(0xd4 + index);
		
	sleep_ms(25);
	
	tmp = x;
	
	if(tmp < 10)
	{
		tmp = tmp | 0x30;
		lcd_data(tmp);
	}
}

void Hex_8_Display(unsigned char x, unsigned char index, unsigned char line)
{
	if(line == 1)
		lcd_cmd(0x80 + index);
	else if(line == 2) 
		lcd_cmd(0xc0 + index);
	else if(line == 3)
		lcd_cmd(0x94 + index);
	else
		lcd_cmd(0xd4 + index);		
	sleep_ms(30);
	CHARACTER_TO_LCD_HEX((x>>4) & 0xf);
	CHARACTER_TO_LCD_HEX( x & 0xf);
}

void Hex_16_Display(unsigned int x, unsigned char index, unsigned char line)
{
	if(line == 1)
		lcd_cmd(0x80 + index);
	else if(line == 2) 
		lcd_cmd(0xc0 + index);
	else if(line == 3)
		lcd_cmd(0x94 + index);
	else
		lcd_cmd(0xd4 + index);
	
	sleep_ms(30);
	Hex_8_Display(x&0xff,index+2,line);

	Hex_8_Display((x>>8)&0xff,index,line);
}
void Dec_8_Display(unsigned char x, unsigned char index, unsigned char line)
{
	if(line == 1)
		lcd_cmd(0x80 + index);
	else if(line == 2) 
		lcd_cmd(0xc0 + index);
	else if(line == 3)
		lcd_cmd(0x94 + index);
	else
		lcd_cmd(0xd4 + index);
		
	sleep_ms(25);
	CHARACTER_TO_BCD(x/10,index,line);
	CHARACTER_TO_BCD(x%10,index+1,line);
}
void Dec_16_Display(unsigned int x, unsigned char index, unsigned char line)
{
	if(line == 1)
		lcd_cmd(0x80 + index);
	else if(line == 2) 
		lcd_cmd(0xc0 + index);
	else if(line == 3)
		lcd_cmd(0x94 + index);
	else
		lcd_cmd(0xd4 + index);
		
	sleep_ms(25);
	Dec_8_Display(x/100,index,line);
	Dec_8_Display(x%100,index+2,line);
}


void DisplayLogo(void)
{
	lcd_clear();
	StrDisplay("  Hello World   ", 0, 1);
    StrDisplay(" Orange Pi Lite ", 0, 2);
}


int main(int argc, char **argv)
{
	
	printf ("Open /dev/mygpio device\r\n");
	gpio_fd = open("/dev/mygpio", 0);

	if (gpio_fd< 0)
	{
		perror("open device /dev/mygpio");
		exit(1);
	}

	lcd_init();
	DisplayLogo();

	for (;;)
	{
		ioctl(gpio_fd, 1, 6);	//Turn off Led 1
		sleep(1);				//	1 second
		ioctl(gpio_fd, 0, 6);	//Turn on Led 1
		sleep_ms(500);			//	500 millisecond
	}

	close(gpio_fd);
	
	return (0);
}




