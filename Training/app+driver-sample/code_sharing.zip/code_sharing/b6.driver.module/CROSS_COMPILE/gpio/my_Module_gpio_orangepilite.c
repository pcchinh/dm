#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/miscdevice.h>
#include <linux/fs.h>
#include <linux/types.h>
#include <linux/moduleparam.h>
#include <linux/slab.h>
#include <linux/ioctl.h>
#include <linux/cdev.h>
#include <linux/delay.h>

#include <linux/gpio.h>	//gpio functions Linux/include/linux/gpio.h


#include <mach/gpio.h>	//arch/arm/mach-sunxi/include/mach/gpio.h


#define DEVICE_NAME "mygpio"

static int ctrl_gpios[] = {	//LCD1602	Button	LED
	TCC_GPA(7),			//->D4
	TCC_GPA(8),			//->D5
	TCC_GPA(9),			//->D6
	TCC_GPA(10),			//->D7
	TCC_GPA(20),			//->RS
	TCC_GPA(21),			//->EN			K1
	TCC_GPD(14),			//						lED1	
	TCC_GPC(4),			//						lED2
	TCC_GPC(7),			//						LED3
};


#define GPIO_NUM		ARRAY_SIZE(ctrl_gpios)


static long orangepilite_gpio_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	switch(cmd) {
		case 0:
		case 1:
			if (arg > GPIO_NUM) {
				return -EINVAL;
			}

			gpio_set_value(ctrl_gpios[arg], cmd);
			
			printk(DEVICE_NAME": %ld %d\n", arg, cmd);
			
			break;

		default:
			return -EINVAL;
	}

	return 0;
}

static struct file_operations orangepilite_gpio_dev_fops = {
	.owner			= THIS_MODULE,
	.unlocked_ioctl	= orangepilite_gpio_ioctl,
};

static struct miscdevice orangepilite_gpio_dev = {
	.minor			= MISC_DYNAMIC_MINOR,
	.name			= DEVICE_NAME,
	.fops			= &orangepilite_gpio_dev_fops,
};

static int __init orangepilite_gpio_dev_init(void)
{
	int ret;
	int i;
	
	
	for (i = 0; i < GPIO_NUM; i++)
	{
		gpio_free(ctrl_gpios[i]);
	}
	
	for (i = 0; i < GPIO_NUM; i++)
	{
		ret = gpio_request(ctrl_gpios[i], "ctl_gpio");
		if (ret) {
			printk("%s: request GPIO %d for control failed, ret = %d\n", DEVICE_NAME, ctrl_gpios[i], ret);
			return ret;
		}

		gpio_direction_output(ctrl_gpios[i], 1);
		
		gpio_set_value(ctrl_gpios[i], 1);
	}

	ret = misc_register(&orangepilite_gpio_dev);	//Miscellaneous Character Drivers

	printk(DEVICE_NAME" Module is initialized\n");

	return ret;
}

static void __exit orangepilite_gpio_dev_exit(void)
{
	int i;

	for (i = 0; i < GPIO_NUM; i++)
	{
		gpio_free(ctrl_gpios[i]);
	}

	misc_deregister(&orangepilite_gpio_dev);
	
	printk(DEVICE_NAME" Module is Removed\n");
}

module_init(orangepilite_gpio_dev_init);
module_exit(orangepilite_gpio_dev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Nguyen Tan Thinh [thinh.nttech@gmail.com]; http://htembeddedsystem.com");
MODULE_DESCRIPTION("Orange Pi Lite [gpio driver module]");

