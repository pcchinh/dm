#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/sched.h>
#include <linux/poll.h>
#include <linux/irq.h>
#include <asm/irq.h>
#include <asm/io.h>
#include <linux/interrupt.h>
#include <asm/uaccess.h>
#include <mach/hardware.h>
#include <linux/platform_device.h>
#include <linux/cdev.h>
#include <linux/miscdevice.h>

#include <linux/gpio.h>
#include <mach/gpio.h>


struct task_struct *task;
struct siginfo      sinfo;    /* signal information */
pid_t my_pid;




#define DEVICE_NAME		"my_buttons"

struct button_desc {
	int gpio;
	int number;
	char *name;
	struct timer_list timer;
};

static struct button_desc buttons[] = {
	{ TCC_GPA(21), 0, "KEY0" },
};

static volatile char key_values[] = {
	'0'
};

static DECLARE_WAIT_QUEUE_HEAD(button_waitq);

static volatile int ev_press = 0;


static void htest_buttons_timer(unsigned long _data)
{
	struct button_desc *bdata = (struct button_desc *)_data;
	int down;
	int number;
	unsigned tmp;

	tmp = gpio_get_value(bdata->gpio);

	/* active low */
	down = !tmp;
	printk("KEY %d: %08x\n", bdata->number, down);

	number = bdata->number;
	if (down != (key_values[number] & 1)) {
		key_values[number] = '0' + down;

		ev_press = 1;
		wake_up_interruptible(&button_waitq);
	}

    //printk("User entered pid %d\n", current->pid);
	// send SIGUSR1 signal from kernel to application
	//pdev->task = find_task_by_vpid (current->pid);
	task= pid_task(find_vpid(my_pid), PIDTYPE_PID);
	if(task == NULL) {
		printk ("Cannot find pid from user program\r\n");
		return;
	}

	send_sig_info (SIGIO, &sinfo, task); // Send signal to user program
}

static irqreturn_t button_interrupt(int irq, void *dev_id)
{
	struct button_desc *bdata = (struct button_desc *)dev_id;

	printk("gpio:%d, number:%d, %s\n", bdata->gpio, bdata->number, bdata->name);

	mod_timer(&bdata->timer, jiffies + msecs_to_jiffies(40));

	printk("jiffies=%ld; ms2jiffies:%ld; HZ=1S: %d\n", jiffies, msecs_to_jiffies(40),HZ);

	return IRQ_HANDLED;
}

static int htest_buttons_open(struct inode *inode, struct file *file)
{
	int irq;
	int i;
	int err = 0;

    my_pid = current->pid;

	for (i = 0; i < ARRAY_SIZE(buttons); i++) {
		if (!buttons[i].gpio)
			continue;

		setup_timer(&buttons[i].timer, htest_buttons_timer, (unsigned long)&buttons[i]);

		irq = gpio_to_irq(buttons[i].gpio);
		err = request_irq(irq, button_interrupt, IRQ_TYPE_EDGE_BOTH,
				buttons[i].name, (void *)&buttons[i]);
		if (err)
			break;
	}

	if (err) {
		i--;
		for (; i >= 0; i--) {
			if (!buttons[i].gpio)
				continue;

			irq = gpio_to_irq(buttons[i].gpio);
			disable_irq(irq);
			free_irq(irq, (void *)&buttons[i]);

			del_timer_sync(&buttons[i].timer);
		}

		return -EBUSY;
	}

	ev_press = 1;
	return 0;
}

static int htest_buttons_close(struct inode *inode, struct file *file)
{
	int irq, i;

	for (i = 0; i < ARRAY_SIZE(buttons); i++) {
		if (!buttons[i].gpio)
			continue;

		irq = gpio_to_irq(buttons[i].gpio);
		free_irq(irq, (void *)&buttons[i]);

		del_timer_sync(&buttons[i].timer);
	}

	return 0;
}

static int htest_buttons_read(struct file *filp, char __user *buff,
		size_t count, loff_t *offp)
{
	unsigned long err;

	if (!ev_press) {
		if (filp->f_flags & O_NONBLOCK)
			return -EAGAIN;
		else
			wait_event_interruptible(button_waitq, ev_press);
	}

	ev_press = 0;

	err = copy_to_user((void *)buff, (const void *)(&key_values),
			min(sizeof(key_values), count));

	return err ? -EFAULT : min(sizeof(key_values), count);
}

static unsigned int htest_buttons_poll( struct file *file,
		struct poll_table_struct *wait)
{
	unsigned int mask = 0;

	poll_wait(file, &button_waitq, wait);
	if (ev_press)
		mask |= POLLIN | POLLRDNORM;

	return mask;
}

static struct file_operations dev_fops = {
	.owner		= THIS_MODULE,
	.open		= htest_buttons_open,
	.release	= htest_buttons_close,
	.read		= htest_buttons_read,
	.poll		= htest_buttons_poll,
};

static struct miscdevice misc = {
	.minor		= MISC_DYNAMIC_MINOR,
	.name		= DEVICE_NAME,
	.fops		= &dev_fops,
};

static int __init button_dev_init(void)
{
	int ret;
	int irq;
	int err = 0;

	ret = misc_register(&misc);
    	if (ret < 0)
    	{
        	printk (KERN_ALERT "Intitialize fault\n");
    	}
	printk(DEVICE_NAME"\tinitialized\n");

	setup_timer(&buttons[0].timer, htest_buttons_timer,(unsigned long)&buttons[0]);

	gpio_free (buttons[0].gpio);
	ret = gpio_request (buttons[0].gpio, "IRQgpio");
	if (ret)
    	{
        	printk (KERN_ALERT "Unable to request %s\n", buttons[0].name);
	}

	irq = gpio_to_irq(buttons[0].gpio);
	err = request_irq(irq, button_interrupt, IRQ_TYPE_EDGE_BOTH,
				buttons[0].name, (void *)&buttons[0]);
	if (err)
	{
		irq = gpio_to_irq(buttons[0].gpio);
		disable_irq(irq);
		free_irq(irq, (void *)&buttons[0]);

		del_timer_sync(&buttons[0].timer);
		printk(DEVICE_NAME"\t Request interrupt Error\n");


		misc_deregister(&misc);
		return -EBUSY;
	}
	printk(DEVICE_NAME"\tRegister OK\n");
	return ret;
}

static void __exit button_dev_exit(void)
{
	int irq = gpio_to_irq(buttons[0].gpio);
	disable_irq(irq);
	free_irq(irq, (void *)&buttons[0]);

	del_timer_sync(&buttons[0].timer);

	misc_deregister(&misc);

	printk(DEVICE_NAME"exit module\n");
}

module_init(button_dev_init);
module_exit(button_dev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("[thnhngtan@gmail.com]");
MODULE_DESCRIPTION("Orange Pi Lite [button driver module]");
