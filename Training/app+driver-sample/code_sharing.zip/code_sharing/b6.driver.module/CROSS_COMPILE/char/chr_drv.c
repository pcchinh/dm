#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <asm/io.h>
#include <asm/uaccess.h>

#define CHAR_MAJOR	240
#define CHAR_NAME	"char_dev_driver"

static volatile char memory_driver[] = {'0', '0', '0', '0','0', '0', '0', '0'};

static int char_open(struct inode * inode, struct file * fp)
{
	printk("---> char open called! \n");
	printk("dev is 0x%x\n", inode->i_rdev);
	printk("major is %d\n", MAJOR(inode->i_rdev));
	printk("minor is %d\n", MINOR(inode->i_rdev));
	return 0;
}
static int char_release(struct inode * inode, struct file * fb)
{
	printk("---> char release called! \n");
	return 0;
}
static ssize_t char_read(struct file * a, char __user * buf, size_t count, loff_t * d)
{
	unsigned long err;

	printk("---> char read called! \n");
	printk("buf = 0x%x\n",(int)buf);

	err = copy_to_user((void *)buf, (const void *)(&memory_driver), min(sizeof(memory_driver), count));

	return err ? -EFAULT : min(sizeof(memory_driver), count);
}

static ssize_t char_write(struct file * a, const char __user * buf, size_t count, loff_t * d)
{
	unsigned long err;

	printk("---> char write called! \n");
	printk("count = %d\n", count);
	printk("buf = 0x%x\n",(int)buf);
	printk("buf = 0x(%x)\n", (int)buf);

	err = copy_from_user((void *)memory_driver, (const void *)(buf), min(sizeof(memory_driver), count));

	return err ? -EFAULT : min(sizeof(memory_driver), count);
}
struct file_operations char_fops =
{
	.owner = THIS_MODULE,
	.open = char_open,
	.release = char_release,
	.read = char_read,
	.write = char_write,
};
int char_init(void)
{
	int rc;
	printk("character init ok \n");
	printk("MAJOR = %d\n", CHAR_MAJOR);
	// register char dev
	rc = register_chrdev(CHAR_MAJOR, CHAR_NAME, &char_fops);
	printk("rc = %d\n", rc);
	return 0;
}
void char_exit(void)
{
	printk("character driver exit ok \n");
	// unregister
	unregister_chrdev(CHAR_MAJOR, CHAR_NAME);
	return;
}
module_init(char_init);
module_exit(char_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("thnhngtan@gmail.com/");
MODULE_DESCRIPTION("Orange Pi Lite [character device driver]");
