#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(int argc, char **argv)
{
	int fd;
	char test_chr[] = "hello!";

	fd = open("/dev/char_dev_driver", O_RDWR);
	if (fd < 0) {
		perror("open character driver error\r\n");
		exit(1);
	}

	printf ("Before write test_chr is %s \r\n", test_chr);
	if (write(fd, test_chr, sizeof(test_chr)) != sizeof(test_chr))
		printf ("write error \r\n");

	memset (test_chr, 0x0, sizeof(test_chr) );

	if (read(fd, test_chr, sizeof(test_chr)) != sizeof(test_chr))
		printf ("read error \r\n");

	printf ("apter write:\r\n");
	printf ("%s\r\n", test_chr);

	printf ("the end\r\n");
	close(fd);
	return (0);
}

