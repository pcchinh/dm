/*hello.c - The simplest kernel module */
#include   <linux/kernel.h>
#include   <linux/init.h>
#include   <linux/module.h>

static   int  __init   my_led_init(void)
{
	printk("Hello led module\n");
	return 0;
}

static   void   __exit  my_led_exit(void)
{
	printk("Goodbye led module\n");
}

module_init(my_led_init);
module_exit(my_led_exit);
MODULE_LICENSE("GPL"); 
MODULE_AUTHOR("thinh.namtientech@gmail.com"); 
MODULE_DESCRIPTION("Simple led driver module");
