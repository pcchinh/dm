#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
/* in the /dev/mygpio device file:
 * 	gpio number: 	0	-> GPIOA7,
 *					1	-> GPIOA8,
 *					2	-> GPIOA9,
 *					3	-> GPIOA10
 *					4	-> GPIOA20,
 *					5	-> GPIOA21,
 *					6	-> GPIOD14
 *					7	-> GPIOC4
 *					8	-> GPIOC7
*/
void sleep_ms(int milliseconds)
{
	usleep(milliseconds * 1000);
}

int main(int argc, char **argv)
{
	int on = 0;
	int off = 1;
	int fd;

	fd = open("/dev/mygpio", 0);
	if (fd < 0) {
		perror("open device leds");
		exit(1);
	}
	for (;;)
	{
		ioctl(fd, off, 6);
		ioctl(fd, off, 7);
		ioctl(fd, off, 8);
		sleep(1);
		ioctl(fd, on, 6);
		ioctl(fd, on, 7);
		ioctl(fd, on, 8);
		sleep_ms(100);
	}

	close(fd);
	return (0);
}

